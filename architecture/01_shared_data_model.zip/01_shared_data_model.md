# Shared Data Model

All tables live in one database for one product: reachfyp.com (creator marketplace).

---

## Core Entities

### users
| field | type | notes |
|---|---|---|
| id | uuid | primary key |
| email | varchar | unique |
| password_hash | varchar | |
| full_name | varchar | |
| username | varchar | unique |
| avatar_url | varchar | |
| country | varchar | |
| timezone | varchar | |
| status | enum | active / suspended / pending_review |
| email_verified | boolean | |
| created_at | timestamp | |
| updated_at | timestamp | |

---

### user_roles
One user can hold multiple roles.

| field | type | notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | FK → users |
| role | enum | brand / creator / admin |
| is_active | boolean | |
| granted_at | timestamp | |

---

### creator_profiles
| field | type | notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | FK → users (1:1) |
| bio | text | |
| niche | varchar[] | array of tags |
| location | varchar | |
| languages | varchar[] | |
| profile_visibility | enum | public / private |
| verification_status | enum | unverified / pending / verified |
| quality_score | decimal | 0-100 delivery/review quality |
| avg_rating | decimal | |
| review_count | integer | |
| total_campaigns_completed | integer | |
| is_featured | boolean | |
| created_at | timestamp | |
| updated_at | timestamp | |

---

### creator_social_links
| field | type | notes |
|---|---|---|
| id | uuid | |
| creator_id | uuid | FK → creator_profiles |
| platform | enum | instagram / tiktok / youtube / x / facebook / other |
| handle | varchar | |
| profile_url | varchar | |
| follower_count | integer | auto-sync after OAuth connect |
| engagement_rate | decimal | auto-sync metric |
| post_count | integer | auto-sync metric |
| is_verified | boolean | verified by platform OAuth |
| connected_at | timestamp | |
| verified_at | timestamp | |

---

### creator_metrics
Authenticity and performance metrics used for ranking.

| field | type | notes |
|---|---|---|
| id | uuid | |
| creator_id | uuid | FK → creator_profiles, unique |
| authenticity_score | decimal | 0-100 composite trust score |
| avg_views | decimal | rolling average views |
| engagement_rate | decimal | rolling engagement rate |
| audience_quality_score | decimal | 0-100 audience quality |
| growth_anomaly_score | decimal | 0-100 anomaly risk |
| performance_score | decimal | 0-100 from tracking outcomes |
| ranking_score | decimal | weighted score for sort order |
| last_calculated_at | timestamp | |
| created_at | timestamp | |
| updated_at | timestamp | |

---

### creator_packages
| field | type | notes |
|---|---|---|
| id | uuid | |
| creator_id | uuid | FK → creator_profiles |
| title | varchar | e.g. "Instagram Reel" |
| description | text | |
| platform | enum | instagram / tiktok / youtube / etc |
| content_type | enum | reel / story / post / video / ugc / review / custom |
| price | decimal | |
| currency | varchar | default USD |
| delivery_days | integer | |
| revisions | integer | |
| requirements | text | what brand must provide |
| instant_hire_enabled | boolean | default true |
| is_active | boolean | |
| created_at | timestamp | |
| updated_at | timestamp | |

---

### creator_portfolio
| field | type | notes |
|---|---|---|
| id | uuid | |
| creator_id | uuid | FK → creator_profiles |
| title | varchar | |
| media_url | varchar | image/video URL |
| external_url | varchar | link to live post |
| platform | varchar | |
| created_at | timestamp | |

---

### campaigns
| field | type | notes |
|---|---|---|
| id | uuid | |
| brand_id | uuid | FK → users |
| title | varchar | |
| objective | varchar | awareness / traffic / conversions / ugc |
| description | text | |
| budget | decimal | |
| currency | varchar | |
| platforms | varchar[] | |
| niche | varchar[] | |
| deliverables | text | |
| timeline_start | date | |
| timeline_end | date | |
| requirements | text | |
| status | enum | draft / open / in_progress / completed / cancelled |
| created_at | timestamp | |
| updated_at | timestamp | |

---

### campaign_applications
| field | type | notes |
|---|---|---|
| id | uuid | |
| campaign_id | uuid | FK → campaigns |
| creator_id | uuid | FK → creator_profiles |
| package_id | uuid | FK → creator_packages (optional) |
| message | text | |
| proposed_price | decimal | |
| status | enum | pending / accepted / rejected / withdrawn |
| applied_at | timestamp | |
| reviewed_at | timestamp | |

---

### campaign_hires (active engagements)
| field | type | notes |
|---|---|---|
| id | uuid | |
| campaign_id | uuid | FK → campaigns, nullable for direct package hire |
| creator_id | uuid | FK → creator_profiles |
| package_id | uuid | FK → creator_packages |
| brand_id | uuid | FK → users |
| hire_type | enum | instant / application / invite |
| agreed_price | decimal | |
| currency | varchar | |
| status | enum | invited / accepted / in_progress / submitted / revision_requested / approved / completed / disputed / cancelled |
| hired_at | timestamp | |
| deadline | timestamp | |
| completed_at | timestamp | |

---

### deliverables
| field | type | notes |
|---|---|---|
| id | uuid | |
| hire_id | uuid | FK → campaign_hires |
| title | varchar | |
| description | text | |
| file_urls | varchar[] | uploaded files |
| external_url | varchar | live post URL |
| notes | text | creator notes |
| status | enum | pending / submitted / approved / rejected / revision_requested |
| submitted_at | timestamp | |
| reviewed_at | timestamp | |
| reviewer_id | uuid | FK → users |
| feedback | text | brand/admin feedback |
| revision_count | integer | |

---

### conversations
| field | type | notes |
|---|---|---|
| id | uuid | |
| type | enum | direct / campaign / hire |
| reference_id | uuid | campaign_id or hire_id |
| participant_ids | uuid[] | |
| last_message_at | timestamp | |
| created_at | timestamp | |

---

### messages
| field | type | notes |
|---|---|---|
| id | uuid | |
| conversation_id | uuid | FK → conversations |
| sender_id | uuid | FK → users |
| content | text | |
| media_urls | varchar[] | |
| read_at | timestamp | |
| created_at | timestamp | |

---

### wallet_accounts
| field | type | notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | FK → users (1:1) |
| balance | decimal | current available balance |
| held_balance | decimal | funds in escrow |
| currency | varchar | |
| updated_at | timestamp | |

---

### wallet_transactions
| field | type | notes |
|---|---|---|
| id | uuid | |
| wallet_id | uuid | FK → wallet_accounts |
| type | enum | deposit / withdrawal / escrow_hold / escrow_release / payout / refund / admin_adjustment |
| amount | decimal | |
| direction | enum | credit / debit |
| reference_type | varchar | campaign_hire / payout / dispute |
| reference_id | uuid | |
| note | text | |
| created_by | uuid | user or system |
| created_at | timestamp | |

---

### payouts
| field | type | notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | FK → users |
| amount | decimal | |
| method | enum | bank_transfer / paypal / wise / crypto / etc |
| payout_details | jsonb | masked destination info |
| status | enum | pending / processing / completed / failed |
| requested_at | timestamp | |
| processed_at | timestamp | |
| admin_id | uuid | who approved |

---

### notifications
| field | type | notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | FK → users |
| type | varchar | new_message / application_accepted / hire_started / payout_processed / etc |
| title | varchar | |
| body | text | |
| data | jsonb | link/context |
| read | boolean | |
| created_at | timestamp | |

---

### reviews
| field | type | notes |
|---|---|---|
| id | uuid | |
| reviewer_id | uuid | FK → users |
| reviewee_id | uuid | FK → users |
| reference_type | enum | campaign_hire |
| reference_id | uuid | |
| rating | integer | 1-5 |
| comment | text | |
| created_at | timestamp | |

---

### tracking_links
| field | type | notes |
|---|---|---|
| id | uuid | |
| campaign_id | uuid | FK → campaigns, nullable |
| hire_id | uuid | FK → campaign_hires |
| creator_id | uuid | FK → creator_profiles |
| short_code | varchar | unique |
| destination_url | varchar | |
| clicks | integer | denormalized counter |
| conversions | integer | denormalized counter |
| unique_clicks | integer | denormalized counter |
| created_at | timestamp | |

---

### tracking_events
| field | type | notes |
|---|---|---|
| id | uuid | |
| link_id | uuid | FK → tracking_links |
| event_type | enum | click / conversion |
| ip_address | inet | |
| user_agent | text | |
| referrer | varchar | |
| country | varchar | |
| quality_score | decimal | traffic quality score (0-100) |
| created_at | timestamp | |

---

### audit_logs
| field | type | notes |
|---|---|---|
| id | uuid | |
| actor_id | uuid | FK → users |
| action | varchar | |
| target_type | varchar | |
| target_id | uuid | |
| metadata | jsonb | before/after snapshot |
| ip_address | inet | |
| created_at | timestamp | |

---

### disputes
| field | type | notes |
|---|---|---|
| id | uuid | |
| hire_id | uuid | FK → campaign_hires |
| opened_by | uuid | FK → users |
| reason | text | |
| status | enum | open / under_review / resolved / closed |
| resolution | enum | release_funds / refund_brand / split_payment |
| admin_id | uuid | |
| resolved_at | timestamp | |
| created_at | timestamp | |
