# Product Architecture - Index

This folder contains the structural plan for one product only: reachfyp.com (creator marketplace).

## Strategic Direction

- No dual-platform scope
- No worker role
- No task system
- Product focus: performance + authenticity driven creator hiring

## Files

| File | Contents |
|---|---|
| 01_shared_data_model.md | Database schema for marketplace, campaigns, hires, messaging, wallet, tracking, metrics |
| 02_roles_permissions.md | Role model (brand/creator/admin), permission matrix, auth strategy |
| 03_user_flows.md | Step-by-step flows for creator, brand, admin, trust and ranking loops |
| 04_page_maps.md | Routes for public pages, brand dashboard, creator dashboard, and admin panel |
| 05_module_architecture.md | Backend modules, API routes, frontend structure, and implementation sequence |

## Build Order Summary

Phase 1 (Core Launch):
auth -> profiles -> social connect -> packages -> instant hire -> hires -> deliverables -> wallet/escrow -> messaging

Phase 2 (Market Advantage):
tracking links -> conversion events -> creator metrics -> smart ranking -> analytics

Phase 3 (Operational Scale):
verification hardening -> disputes tooling -> payout ops -> admin automation
