# User Roles and Permissions

---

## Role Definitions

| Role | Purpose | Product Area |
|---|---|---|
| brand | Posts campaigns, hires creators, manages deliverables and payments | reachfyp marketplace |
| creator | Builds profile, connects socials, sells packages, delivers work | reachfyp marketplace |
| admin | Full system access, trust and payout controls, moderation | reachfyp platform |

A single user account can hold multiple roles simultaneously.
Example: a creator can also be a brand.

---

## Permission Matrix

### auth
| action | brand | creator | admin |
|---|---|---|---|
| register | ✓ | ✓ | — |
| login | ✓ | ✓ | ✓ |
| change password | ✓ | ✓ | ✓ |
| delete own account | ✓ | ✓ | — |

---

### creator profiles and social connect
| action | brand | creator | admin |
|---|---|---|---|
| view public profile | ✓ | ✓ | ✓ |
| create own profile | — | ✓ | ✓ |
| edit own profile | — | ✓ | ✓ |
| connect social accounts (OAuth) | — | ✓ | ✓ |
| sync social metrics | — | ✓ | ✓ |
| view all creator profiles | — | — | ✓ |
| verify a creator | — | — | ✓ |
| suspend a creator | — | — | ✓ |

---

### creator packages and instant hire
| action | brand | creator | admin |
|---|---|---|---|
| view packages | ✓ | ✓ | ✓ |
| create/edit own packages | — | ✓ | — |
| delete own package | — | ✓ | — |
| enable/disable instant hire on package | — | ✓ | ✓ |
| hire instantly from package | ✓ | — | ✓ |
| deactivate any package | — | — | ✓ |

---

### campaigns
| action | brand | creator | admin |
|---|---|---|---|
| post a campaign | ✓ | — | ✓ |
| edit own campaign | ✓ | — | ✓ |
| cancel own campaign | ✓ | — | ✓ |
| view open campaigns | ✓ | ✓ | ✓ |
| apply to campaign | — | ✓ | — |
| accept/reject application | ✓ | — | ✓ |
| view all campaigns | — | — | ✓ |

---

### campaign hires and deliverables
| action | brand | creator | admin |
|---|---|---|---|
| submit deliverable | — | ✓ | — |
| request revision | ✓ | — | ✓ |
| approve deliverable | ✓ | — | ✓ |
| reject deliverable | ✓ | — | ✓ |
| view hire status | ✓ | ✓ | ✓ |
| cancel hire | ✓ | — | ✓ |
| raise dispute | ✓ | ✓ | — |

---

### wallet and payouts
| action | brand | creator | admin |
|---|---|---|---|
| view own balance | ✓ | ✓ | ✓ |
| deposit funds | ✓ | — | — |
| request payout | — | ✓ | — |
| view own transactions | ✓ | ✓ | ✓ |
| view all wallets | — | — | ✓ |
| manual balance adjustment | — | — | ✓ (logged) |
| approve payout | — | — | ✓ |

---

### messaging
| action | brand | creator | admin |
|---|---|---|---|
| send message | ✓ | ✓ | ✓ |
| read own messages | ✓ | ✓ | ✓ |
| read any conversation | — | — | ✓ |

---

### reviews and ranking
| action | brand | creator | admin |
|---|---|---|---|
| leave review after completed hire | ✓ | ✓ | — |
| view creator authenticity metrics | ✓ | ✓ | ✓ |
| view creator performance metrics | ✓ | ✓ | ✓ |
| recalculate ranking score | — | — | ✓ |
| delete any review | — | — | ✓ |

---

### admin
| action | brand | creator | admin |
|---|---|---|---|
| access admin panel | — | — | ✓ |
| suspend any user | — | — | ✓ |
| resolve disputes | — | — | ✓ |
| view audit logs | — | — | ✓ |
| manage verification | — | — | ✓ |
| view platform analytics | — | — | ✓ |

---

## Role Assignment Flow

### At Registration
User picks their primary role:
- "I'm a brand" → role: brand
- "I'm a creator" → role: creator

### Adding a Second Role
A user can add the second role later from account settings.
Example: a creator can also activate the brand role.

### Admin Assignment
Admin role is never self-assigned. It is granted directly in the database by a super-admin or via a seeded admin bootstrap script.

---

## Auth Strategy

- JWT-based authentication with refresh tokens
- Tokens include: user_id, active_roles[], current_active_role
- Frontend supports role switching only between brand and creator
- All protected API routes check authentication and role-level permission
- Middleware enforces role-permission matrix per endpoint
