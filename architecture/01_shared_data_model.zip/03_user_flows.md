# User Flows

---

## 1. Creator Flow

### Onboarding
1. Creator registers and selects "I'm a creator"
2. Email verification
3. Creator completes profile:
   - photo, bio, niche, location, languages
   - social account connect (Instagram/TikTok first)
   - portfolio items
4. System syncs social metrics (followers, engagement, post count)
5. Creator creates first package and can enable instant hire
6. Profile goes live (unverified badge initially)
7. Optional: creator requests verification and admin reviews

### Getting Hired (Instant Hire)
1. Brand finds creator in marketplace
2. Brand opens package and clicks "Hire Instantly"
3. Brand funds escrow and confirms payment
4. Hire is created immediately with status: accepted
5. Creator receives notification and starts work
6. Creator submits deliverable (files, URLs, notes)
7. Brand approves, requests revision, or rejects
8. If approved, escrow is released to creator wallet
9. Both parties can leave a review
10. Tracking events update creator performance score

### Applying to a Campaign
1. Creator browses open campaigns
2. Filters by niche, platform, budget, objective
3. Creator submits application (message + proposed price + package)
4. Brand accepts or rejects application
5. If accepted, hire is created and deliverable workflow begins

---

## 2. Brand Flow

### Onboarding
1. Brand registers and selects "I'm a brand"
2. Email verification
3. Optional brand profile setup (company, industry, website)
4. Brand adds payment method or deposits funds

### Discovering and Hiring Creators
1. Brand searches creator marketplace
2. Brand filters by platform, niche, price, verified status
3. Results are sorted by ranking_score (performance + authenticity), not followers alone
4. Brand reviews profile: packages, portfolio, authenticity metrics, performance stats
5. Brand hires instantly from package or sends a custom offer
6. Escrow hold is placed on brand wallet
7. Deliverable workflow starts

### Running Campaigns
1. Brand creates campaign with objective, budget, platforms, timeline, and deliverables
2. Campaign is published with status: open
3. Creators apply to campaign
4. Brand reviews and accepts applications
5. Accepted applications become hires
6. Brand manages hires and tracking outcomes from campaign dashboard

### Managing Deliverables and Results
1. Brand reviews submitted deliverables
2. Brand approves, requests revision, or rejects
3. Approved deliverables release escrow funds
4. Brand monitors tracking links by creator:
   - clicks
   - conversions
   - traffic quality

---

## 3. Admin Flow

### User and Trust Management
1. Admin manages users by role, status, and geography
2. Admin verifies creators and can suspend accounts
3. Admin reviews audit logs and role changes

### Metrics and Ranking Oversight
1. Admin monitors creator_metrics recalculation jobs
2. Admin reviews authenticity anomalies (growth spikes, low audience quality)
3. Admin can trigger manual recalculation of ranking_score

### Disputes and Payouts
1. Admin resolves disputes on hires
2. Admin executes fund resolution (release, refund, split)
3. Admin processes creator payout requests

### Platform Analytics
1. Admin tracks marketplace health:
   - new creators/brands
   - hire conversion rate
   - delivery approval rate
   - payout throughput
   - tracking quality signals

---

## 4. Shared Flows

### Messaging
1. Conversation is created when:
   - brand sends custom offer
   - creator applies to campaign
   - a hire starts
2. Brand and creator communicate in threaded chat
3. Admin can view conversations for moderation

### Notifications
Events that trigger notifications:
- application received / accepted / rejected
- instant hire created
- deliverable submitted / approved / rejected / revision requested
- new message received
- payout processed
- dispute opened / resolved
- social account connected / sync failed
- verification approved / rejected

### Wallet and Escrow
Hire created:
1. Brand wallet: balance decreases and held_balance increases
2. Transaction type: escrow_hold

Deliverable approved:
1. Brand wallet: held_balance decreases
2. Creator wallet: balance increases
3. Transaction types: escrow_release and payout

Hire cancelled before work:
1. Held funds return to brand balance
2. Transaction type: refund

---

## 5. Trust and Ranking Flows

### Creator Authenticity Score
1. Metrics service ingests social and platform behavior signals
2. System computes:
   - authenticity_score
   - audience_quality_score
   - growth_anomaly_score
3. Scores are persisted to creator_metrics

### Performance Tracking Score
1. Each hire can generate tracking links
2. Click and conversion events are captured
3. Event quality is scored (traffic quality)
4. Creator performance_score is updated from event outcomes

### Smart Marketplace Ranking
1. ranking_score is calculated from weighted metrics:
   - authenticity_score
   - performance_score
   - delivery quality_score
   - review signals
2. Marketplace defaults to ranking_score sort
3. Follower count remains visible but not primary ranking input
