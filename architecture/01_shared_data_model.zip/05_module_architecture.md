# Module Architecture

---

## System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                      reachfyp.com BACKEND                           │
│                                                                     │
│  ┌──────────┐ ┌─────────────┐ ┌───────────┐ ┌───────────────────┐  │
│  │   auth   │ │ users/roles │ │  wallet   │ │   notifications   │  │
│  └──────────┘ └─────────────┘ └───────────┘ └───────────────────┘  │
│                                                                     │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                  MARKETPLACE CORE MODULES                     │  │
│  │  creators  packages  campaigns  applications  hires           │  │
│  │  deliverables  messaging  reviews  disputes                   │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                    DIFFERENTIATOR MODULES                     │  │
│  │  social_connect  creator_metrics  tracking  ranking           │  │
│  │  authenticity scoring + performance scoring engine            │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │                 ADMIN AND PLATFORM SERVICES                   │  │
│  │  moderation  verification  analytics  payouts  audit logs     │  │
│  └────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                                                    │
                                                    ▼
                             ┌────────────────────────────┐
                             │  reachfyp.com Frontend     │
                             │  (public + brand/creator)  │
                             └────────────────────────────┘
                                                    │
                                                    ▼
                             ┌────────────────────────────┐
                             │        Admin Panel         │
                             └────────────────────────────┘
```

---

## Backend Modules

### 1. auth
Responsibilities:
- Register, login, logout
- JWT access token + refresh token
- Email verification and password reset
- Role assignment (brand or creator)

API routes:
- POST /auth/register
- POST /auth/login
- POST /auth/logout
- POST /auth/refresh
- POST /auth/verify-email
- POST /auth/forgot-password
- POST /auth/reset-password

---

### 2. users
Responsibilities:
- User CRUD
- Profile basics and account status
- Role activation (brand/creator only)

API routes:
- GET /users/me
- PUT /users/me
- GET /users/:id (admin)
- PUT /users/:id/status (admin)
- POST /users/:id/roles (admin)

---

### 3. creator_profiles
Responsibilities:
- Creator profile CRUD
- Portfolio and verification requests

API routes:
- GET /creators
- GET /creators/:username
- POST /creators/profile
- PUT /creators/profile
- POST /creators/profile/portfolio
- POST /creators/verification/request
- PUT /creators/:id/verification (admin)

---

### 4. social_connect
Responsibilities:
- OAuth connection for Instagram/TikTok (expand later)
- Social metric sync (followers, engagement, posts)
- Connection health and refresh

API routes:
- POST /creators/social/connect/:platform
- DELETE /creators/social/connect/:platform
- POST /creators/social/sync
- GET /creators/social/status

---

### 5. packages
Responsibilities:
- Package CRUD per creator
- Instant hire enable/disable per package

API routes:
- GET /creators/:id/packages
- POST /packages
- PUT /packages/:id
- DELETE /packages/:id
- PUT /packages/:id/instant-hire

---

### 6. campaigns
Responsibilities:
- Campaign CRUD for brands
- Discovery and applications for creators

API routes:
- GET /campaigns
- POST /campaigns
- PUT /campaigns/:id
- GET /campaigns/:id
- DELETE /campaigns/:id
- POST /campaigns/:id/apply
- GET /campaigns/:id/applications
- PUT /campaigns/:id/applications/:app_id

---

### 7. hires
Responsibilities:
- Hire lifecycle management
- Create hires from accepted applications or instant package checkout

API routes:
- POST /hires
- POST /hires/instant
- GET /hires/:id
- PUT /hires/:id/status
- GET /brands/hires
- GET /creators/hires

---

### 8. deliverables
Responsibilities:
- Deliverable submission and review
- Revision and approval workflow

API routes:
- POST /hires/:hire_id/deliverables
- GET /hires/:hire_id/deliverables
- PUT /deliverables/:id/review
- GET /deliverables/:id

---

### 9. messaging
Responsibilities:
- Conversation and message management
- Read status and attachments

API routes:
- GET /conversations
- POST /conversations
- GET /conversations/:id/messages
- POST /conversations/:id/messages
- PUT /messages/:id/read

---

### 10. wallet
Responsibilities:
- Balance management
- Escrow hold/release and refunds
- Transaction ledger

API routes:
- GET /wallet/me
- GET /wallet/transactions
- POST /wallet/deposit
- GET /admin/wallets
- POST /admin/wallet/:user_id/adjust

---

### 11. payouts
Responsibilities:
- Creator payout requests
- Admin payout processing

API routes:
- GET /payouts/mine
- POST /payouts/request
- GET /admin/payouts
- PUT /admin/payouts/:id/process
- PUT /admin/payouts/:id/complete

---

### 12. tracking
Responsibilities:
- Tracking link creation per hire
- Click and conversion logging
- Traffic quality scoring

API routes:
- POST /tracking/links
- GET /tracking/links/:hire_id
- GET /t/:code
- POST /tracking/events/conversion
- GET /tracking/links/:id/stats

---

### 13. creator_metrics
Responsibilities:
- Calculate authenticity and performance metrics
- Persist ranking_score for marketplace sort

API routes:
- GET /creators/:id/metrics
- GET /creators/:id/ranking
- POST /admin/metrics/recalculate/:creator_id
- POST /admin/metrics/recalculate-all

---

### 14. ranking
Responsibilities:
- Expose smart creator ranking queries
- Weighted sort across authenticity, performance, and quality

API routes:
- GET /creators/ranked
- GET /creators/ranked/trending
- GET /admin/ranking/config
- PUT /admin/ranking/config

---

### 15. notifications
Responsibilities:
- Event-driven notifications
- Read/unread status

API routes:
- GET /notifications
- PUT /notifications/:id/read
- PUT /notifications/read-all

---

### 16. reviews
Responsibilities:
- Post-hire reviews and aggregation

API routes:
- POST /reviews
- GET /creators/:id/reviews

---

### 17. admin
Responsibilities:
- User, campaign, hire moderation
- Dispute resolution
- Audit log and analytics access

API routes:
- GET /admin/users
- PUT /admin/users/:id
- GET /admin/campaigns
- GET /admin/hires
- GET /admin/disputes
- PUT /admin/disputes/:id/resolve
- GET /admin/analytics
- GET /admin/audit-logs

---

## Frontend Architecture

### reachfyp.com App
- Framework: Next.js
- Public pages: SEO-optimized marketplace and creator profiles
- Auth dashboards: brand and creator areas in one app
- Primary differentiator surfaces:
    - authenticity metrics on profiles
    - performance stats from tracking
    - instant hire checkout flow

### Admin Panel
- Framework: Next.js or React SPA
- Focus: queues, moderation, payouts, ranking controls

### Shared Design System
- Component library used by app and admin
- Token-based theme and spacing system
- Shared components: Button, Input, Form, Modal, Table, Badge, Avatar, Card, Toast, Tabs, Sidebar

---

## Data and Infrastructure

### Database
- PostgreSQL (single primary)

### File Storage
- S3-compatible storage for deliverables, portfolio media, avatars

### Background Jobs / Queues
- Social metric sync
- Metrics recalculation (authenticity/performance/ranking)
- Escrow release and refund events
- Notification dispatch
- Payout processing

### Caching
- Redis for sessions, marketplace query caching, notification counts

### Email
- Transactional email for verification, hire updates, payout status, disputes

---

## Build Sequence (V1 Priority Order)

1. auth + users + roles
2. creator profiles + social connect + packages
3. marketplace search + smart ranking basics
4. instant hire checkout + hires lifecycle
5. campaigns + applications
6. deliverables + approval workflow
7. wallet + escrow + payouts
8. messaging + notifications
9. tracking links + conversion events
10. creator_metrics scoring engine
11. admin panel (users, campaigns, hires, payouts, disputes)
12. analytics dashboards
