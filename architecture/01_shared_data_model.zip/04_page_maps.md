# Page Maps - reachfyp.com

Single platform only. No worker or task domain.

---

## Public Pages (no login required)

| Route | Page | Purpose |
|---|---|---|
| / | Homepage | Positioning: smarter creator marketplace focused on performance + authenticity |
| /how-it-works | How It Works | Separate sections for brands and creators |
| /pricing | Pricing & Fees | Platform fees and payout info |
| /creators | Creator Marketplace | Search/filter creators, default sort by ranking_score |
| /creators/[username] | Creator Profile | Bio, packages, portfolio, reviews, social stats, authenticity metrics |
| /campaigns | Open Campaigns | Public campaigns creators can apply to |
| /campaigns/[id] | Campaign Detail | Campaign brief, brand info, apply CTA |
| /blog | Blog (optional V1) | SEO and trust content |
| /faq | FAQ | Common questions |
| /login | Login | |
| /register | Register | Role selection: brand or creator |
| /register/brand | Brand Registration | |
| /register/creator | Creator Registration | |
| /forgot-password | Forgot Password | |
| /reset-password | Reset Password | |

---

## Brand Dashboard (auth required, role: brand)

| Route | Page | Purpose |
|---|---|---|
| /dashboard | Brand Home | Summary: active hires, campaigns, messages, wallet, performance |
| /dashboard/discover | Discover Creators | Marketplace search with smart ranking filters |
| /dashboard/creators/[id] | Creator Snapshot | Fast decision view with authenticity + performance cards |
| /dashboard/instant-hire/[package_id] | Instant Hire Checkout | Confirm package, escrow payment, hire creation |
| /dashboard/campaigns | My Campaigns | List all campaigns |
| /dashboard/campaigns/new | Post Campaign | Campaign creation form |
| /dashboard/campaigns/[id] | Campaign Detail | Applications, accepted hires, status |
| /dashboard/campaigns/[id]/applications | Applications | Accept/reject applicants |
| /dashboard/hires | Active Hires | All ongoing hires |
| /dashboard/hires/[hire_id] | Hire Detail | Deliverables, messages, approvals, dispute actions |
| /dashboard/messages | Inbox | All conversations |
| /dashboard/messages/[conversation_id] | Conversation | Single thread |
| /dashboard/wallet | Wallet | Balance, transactions, deposits, escrow |
| /dashboard/analytics | Analytics | Creator-level clicks, conversions, traffic quality |
| /dashboard/settings | Account Settings | Profile, billing, notifications |

---

## Creator Dashboard (auth required, role: creator)

| Route | Page | Purpose |
|---|---|---|
| /creator/dashboard | Creator Home | Summary: active hires, applications, earnings, ranking health |
| /creator/profile | My Profile | Public profile preview and edit entry points |
| /creator/profile/edit | Edit Profile | Bio, niche, location, languages |
| /creator/social-connect | Social Connect | Connect Instagram/TikTok/YouTube and sync metrics |
| /creator/portfolio | Portfolio | Manage portfolio items |
| /creator/packages | My Packages | Packages and instant hire toggles |
| /creator/packages/new | Create Package | Package creation form |
| /creator/packages/[id]/edit | Edit Package | Update package details |
| /creator/campaigns | Browse Campaigns | Discover open campaigns |
| /creator/campaigns/[id] | Campaign Detail | Apply to campaign |
| /creator/applications | My Applications | Status of submitted applications |
| /creator/hires | Active Hires | Accepted hires |
| /creator/hires/[hire_id] | Hire Detail | Submit deliverables, view feedback, chat |
| /creator/messages | Inbox | All conversations |
| /creator/messages/[conversation_id] | Conversation | Single thread |
| /creator/wallet | Wallet | Balance, transactions, payouts |
| /creator/wallet/payout | Request Payout | Withdraw earnings |
| /creator/analytics | My Analytics | Tracking outcomes and content performance |
| /creator/authenticity | Authenticity Center | Authenticity score, audience quality, anomaly signals |
| /creator/verification | Verification | Request and track verification status |
| /creator/settings | Account Settings | Password, notifications, profile settings |

---

## Admin Panel (shared, /admin)

| Route | Page |
|---|---|
| /admin | Dashboard / Overview |
| /admin/users | User Management |
| /admin/users/[id] | User Detail |
| /admin/creators | Creator Management |
| /admin/creators/verification | Verification Queue |
| /admin/creators/metrics | Creator Metrics Monitor |
| /admin/campaigns | Campaign Management |
| /admin/campaigns/[id] | Campaign Detail |
| /admin/hires | Hire Management |
| /admin/hires/[id] | Hire + Deliverable Detail |
| /admin/disputes | Disputes |
| /admin/disputes/[id] | Dispute Detail |
| /admin/wallet | Wallet Overview |
| /admin/payouts | Payout Queue |
| /admin/payouts/[id] | Payout Detail |
| /admin/moderation | Content Moderation Queue |
| /admin/analytics | Platform Analytics |
| /admin/audit-logs | Audit Log |
| /admin/settings | Platform Settings |
